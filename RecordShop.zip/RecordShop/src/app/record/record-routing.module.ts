import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RecordListComponent } from './record-list/record-list.component';
import { RecordDetailComponent } from './record-detail/record-detail.component';
import { DodajPloceComponent } from './dodaj-ploce/dodaj-ploce.component';

const routes: Routes = [
  {

    path: '',
   component: RecordListComponent,

  },

  {
    path: 'add',
    component: DodajPloceComponent,


  },



  {
path: ':id',
component: RecordDetailComponent,

  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RecordRoutingModule { }