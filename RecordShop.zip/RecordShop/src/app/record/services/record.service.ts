import { Injectable } from '@angular/core';
import { records, Record } from '../models/record.model';
import { of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class RecordService {

  private ROOT_URL = 'http://localhost:3000/records';

  constructor(private http: HttpClient) { }

  dodajPloce(record: Record){
    return this.http.post(this.ROOT_URL, record);
  }

  getRecordsFromHttp() {
    return this.http.get<Record[]>(this.ROOT_URL);

  }

  recordFromHttp(id: number) {
    return this.http.get<Record>(`${this.ROOT_URL}/${id}`);
  }

  getRecords(){
    return of(records);
  }

  record(id: number) {
    return of(
      records.find(record => +record.id === +id));
    
  }
}
