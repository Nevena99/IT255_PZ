import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NavbarService } from 'src/app/navbar/services/navbar.service';
import { RecordService } from './../services/record.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dodaj-ploce',
  templateUrl: './dodaj-ploce.component.html',
  styleUrls: ['./dodaj-ploce.component.scss'],
})
export class DodajPloceComponent implements OnInit {


  recordForm = new FormGroup({
    ime: new FormControl('', [Validators.required]),
    zanr: new FormControl('', [Validators.required]),
    image: new FormControl('', [Validators.required]),
    godina: new FormControl('', [Validators.required]),
   
  });

  constructor(
    private router: Router,
    private recordService: RecordService,
    private navbarService: NavbarService,) { }

  ngOnInit() {
    this.navbarService.title.next('Dodaj nove ploce');
  }
  dodajPloce(){
    if(this.recordForm.valid){
      this.recordService.dodajPloce(this.recordForm.value)
      .subscribe(res => {
        this.recordForm.reset();
        this.router.navigate(['/']);
      });
    }
  }

}
