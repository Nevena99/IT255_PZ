import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecordListComponent } from './record-list/record-list.component';
import { RecordRoutingModule } from './record-routing.module';
import { RecordDetailComponent } from './record-detail/record-detail.component';
import { RecordComponent } from './record/record.component';
import { DodajPloceComponent } from './dodaj-ploce/dodaj-ploce.component';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [RecordListComponent,
     RecordDetailComponent, 
     RecordComponent, 
     DodajPloceComponent],
  imports: [
    CommonModule,
    RecordRoutingModule,
    ReactiveFormsModule
  ]
})
export class RecordModule { }
