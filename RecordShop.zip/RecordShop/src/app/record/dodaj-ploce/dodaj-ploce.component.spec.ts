import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DodajPloceComponent } from './dodaj-ploce.component';

describe('DodajPloceComponent', () => {
  let component: DodajPloceComponent;
  let fixture: ComponentFixture<DodajPloceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DodajPloceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DodajPloceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
