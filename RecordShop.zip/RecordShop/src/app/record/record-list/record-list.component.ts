import { Component, OnInit } from '@angular/core';
import { RecordService } from '../services/record.service';
import { Observable } from 'rxjs';
import { Record } from '../models/record.model';
import { NavbarService } from 'src/app/navbar/services/navbar.service';


@Component({
  selector: 'app-record-list',
  templateUrl: './record-list.component.html',
  styleUrls: ['./record-list.component.scss']
})
export class RecordListComponent implements OnInit {
records$: Observable<Record[]>

  constructor(private recordService: RecordService, private navbarService: NavbarService) { }

  ngOnInit(){
    this.records$ = this.recordService.getRecordsFromHttp();
    this.navbarService.title.next('RecordShop');
  }

}
