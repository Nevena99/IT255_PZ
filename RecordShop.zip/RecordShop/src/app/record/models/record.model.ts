import { OuterSubscriber } from 'rxjs/internal/OuterSubscriber';

export interface Record {
    id: number;
    ime: string;
    zanr: string;
    image: string;
    godina: string;
}

export const records: Record[] = [
    {

        id: 1,
        ime: 'Flip Out',
        zanr: 'Mascom izdanja',
        image: 'https://www.mascom.rs/files/products/old/flip-out-prati-me-kroz-zivot-1069.jpg',
        godina: '1984'

    },

    {

        id: 2,
        ime: 'Iznad grada(Vinyl)',
        zanr: 'Mascom izdanja',
        image: 'https://www.mascom.rs/var/thumbs/products/old/ekv_iznad_grada_c_300x0.jpg',
        godina: '1993'

    },
    {

        id: 3,
        ime: 'Defektno efektni',
        zanr: 'Mascom izdanja',
        image: 'https://www.mascom.rs/var/thumbs/products/2018/01-januar/defekt-cover_1516270899_c_300x0.jpg',
        godina: '1981'

    },

]