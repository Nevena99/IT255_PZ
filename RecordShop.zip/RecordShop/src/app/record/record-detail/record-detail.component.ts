import { Component, OnInit, OnDestroy } from '@angular/core';
import { RecordService } from '../services/record.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { Record } from '../models/record.model';
import { NavbarService } from 'src/app/navbar/services/navbar.service';

@Component({
  selector: 'app-record-detail',
  templateUrl: './record-detail.component.html',
  styleUrls: ['./record-detail.component.scss']
})
export class RecordDetailComponent implements OnInit,  OnDestroy{

  id: number;
  recordSub$: Subscription;
  record: Record;

  constructor(
    private recordService: RecordService,
     private navbarService: NavbarService,
    private route: ActivatedRoute,
    
    ) { }

  ngOnInit():void {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.recordSub$ = this.recordService.recordFromHttp(this.id).subscribe(record => {
      this.record = record;
      this.navbarService.title.next(record.ime);
    });

  }
  ngOnDestroy() {
    this.recordSub$.unsubscribe();
  }
  
}
